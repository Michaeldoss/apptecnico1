
import React from "react";

type AppLayoutProps = {
  children: React.ReactNode;
};

const AppLayout: React.FC<AppLayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen bg-base text-textDark">
      <header className="bg-primary text-white px-6 py-4 shadow-md">
        <h1 className="text-2xl font-bold">Sistema Técnico</h1>
      </header>
      <main className="p-6">{children}</main>
      <footer className="bg-primary text-white px-6 py-2 mt-10 text-center">
        <p className="text-sm">&copy; 2025 Doss Group</p>
      </footer>
    </div>
  );
};

export default AppLayout;
